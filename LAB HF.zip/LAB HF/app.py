import time
from huggingface_hub import InferenceClientho

client = InferenceClient(
    provider="fal-ai",
    api_key="HF_TOKEN",
)

text = input("Enter text: ")

max_retries = 3

for attempt in range(1, max_retries + 1):
    try:
        print(f"Trying request {attempt}...")

        audio = client.text_to_speech(
            text,
            model="hexgrad/Kokoro-82M",
        )

        with open("output.wav", "wb") as f:
            f.write(audio)

        print("Done. Saved as output.wav")
        break

    except Exception as e:
        print("Request failed:", e)

        if attempt < max_retries:
            print("Waiting 10 seconds, then retrying...")
            time.sleep(10)
        else:
            print("All retries failed.")